﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using sushi;

namespace sushi.Controllers
{
    public class DevolucionesController : Controller
    {
        private masterEntities db = new masterEntities();

        // GET: Devoluciones
        public ActionResult Index()
        {
            var devoluciones = db.Devoluciones.Include(d => d.Productos).Include(d => d.Ventas);
            return View(devoluciones.ToList());
        }

        // GET: Devoluciones/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Devoluciones devoluciones = db.Devoluciones.Find(id);
            if (devoluciones == null)
            {
                return HttpNotFound();
            }
            return View(devoluciones);
        }

        // GET: Devoluciones/Create
        public ActionResult Create()
        {
            ViewBag.producto_id = new SelectList(db.Productos, "producto_id", "nombre");
            ViewBag.venta_id = new SelectList(db.Ventas, "venta_id", "metodo_pago");
            return View();
        }

        // POST: Devoluciones/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "devolucion_id,venta_id,producto_id,cantidad,fecha_devolucion,motivo,monto_reembolsado")] Devoluciones devoluciones)
        {
            if (ModelState.IsValid)
            {
                db.Devoluciones.Add(devoluciones);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.producto_id = new SelectList(db.Productos, "producto_id", "nombre", devoluciones.producto_id);
            ViewBag.venta_id = new SelectList(db.Ventas, "venta_id", "metodo_pago", devoluciones.venta_id);
            return View(devoluciones);
        }

        // GET: Devoluciones/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Devoluciones devoluciones = db.Devoluciones.Find(id);
            if (devoluciones == null)
            {
                return HttpNotFound();
            }
            ViewBag.producto_id = new SelectList(db.Productos, "producto_id", "nombre", devoluciones.producto_id);
            ViewBag.venta_id = new SelectList(db.Ventas, "venta_id", "metodo_pago", devoluciones.venta_id);
            return View(devoluciones);
        }

        // POST: Devoluciones/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "devolucion_id,venta_id,producto_id,cantidad,fecha_devolucion,motivo,monto_reembolsado")] Devoluciones devoluciones)
        {
            if (ModelState.IsValid)
            {
                db.Entry(devoluciones).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.producto_id = new SelectList(db.Productos, "producto_id", "nombre", devoluciones.producto_id);
            ViewBag.venta_id = new SelectList(db.Ventas, "venta_id", "metodo_pago", devoluciones.venta_id);
            return View(devoluciones);
        }

        // GET: Devoluciones/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Devoluciones devoluciones = db.Devoluciones.Find(id);
            if (devoluciones == null)
            {
                return HttpNotFound();
            }
            return View(devoluciones);
        }

        // POST: Devoluciones/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Devoluciones devoluciones = db.Devoluciones.Find(id);
            db.Devoluciones.Remove(devoluciones);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
