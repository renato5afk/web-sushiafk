﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure; // Needed for DbUpdateConcurrencyException
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using sushi;

namespace sushi.Controllers
{
    public class SucursalesController : Controller
    {
        private masterEntities db = new masterEntities();

        // GET: Sucursales
        public ActionResult Index()
        {
            return View(db.Sucursales.ToList());
        }

        // GET: Sucursales/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Sucursales sucursales = db.Sucursales.Find(id);
            if (sucursales == null)
            {
                return HttpNotFound();
            }
            return View(sucursales);
        }

        // GET: Sucursales/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Sucursales/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "nombre_sucursal,direccion,telefono,ciudad")] Sucursales sucursales) // Removed sucursal_id as it's likely auto-generated
        {
            // Remove sucursal_id from ModelState if it's an auto-generated primary key
            // This prevents "The sucursal_id field is required" errors if it's not submitted by the form.
            // If your ID is NOT auto-generated, remove this line.
            ModelState.Remove("sucursal_id");

            if (ModelState.IsValid)
            {
                try
                {
                    db.Sucursales.Add(sucursales);
                    db.SaveChanges();
                    TempData["SuccessMessage"] = "Sucursal creada exitosamente."; // Success message
                    return RedirectToAction("Index");
                }
                catch (DbUpdateException ex)
                {
                    // Log the exception (e.g., using a logging framework like NLog, Serilog)
                    // For now, you can add it to ModelState for display or debug
                    ModelState.AddModelError("", "Error al guardar la sucursal. Detalles: " + ex.InnerException?.Message ?? ex.Message);
                    // If you want more detailed error, check ex.InnerException.InnerException etc.
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Ocurrió un error inesperado al crear la sucursal. Detalles: " + ex.Message);
                }
            }
            // If ModelState is not valid or an error occurred during save, return to the view with errors
            return View(sucursales);
        }

        // GET: Sucursales/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Sucursales sucursales = db.Sucursales.Find(id);
            if (sucursales == null)
            {
                return HttpNotFound();
            }
            return View(sucursales);
        }

        // POST: Sucursales/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "sucursal_id,nombre_sucursal,direccion,telefono,ciudad")] Sucursales sucursales)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    db.Entry(sucursales).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["SuccessMessage"] = "Sucursal actualizada exitosamente."; // Success message
                    return RedirectToAction("Index");
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    // This handles scenarios where the record might have been modified by another user
                    // between fetching it and saving changes.
                    ModelState.AddModelError("", "La sucursal fue modificada por otro usuario mientras intentabas guardarla. Por favor, recarga e intenta de nuevo.");
                    // Log the exception
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", "Error al actualizar la sucursal. Detalles: " + ex.InnerException?.Message ?? ex.Message);
                    // Log the exception
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Ocurrió un error inesperado al actualizar la sucursal. Detalles: " + ex.Message);
                    // Log the exception
                }
            }
            return View(sucursales);
        }

        // GET: Sucursales/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Sucursales sucursales = db.Sucursales.Find(id);
            if (sucursales == null)
            {
                return HttpNotFound();
            }
            return View(sucursales);
        }

        // POST: Sucursales/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Sucursales sucursales = null; // Initialize to null
            try
            {
                sucursales = db.Sucursales.Find(id);
                if (sucursales == null)
                {
                    return HttpNotFound(); // Record not found, perhaps already deleted
                }

                db.Sucursales.Remove(sucursales);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Sucursal eliminada exitosamente."; // Success message
                return RedirectToAction("Index");
            }
            catch (DbUpdateException ex)
            {
                // This typically indicates a foreign key constraint violation
                // (e.g., trying to delete a sucursal that has associated ventas/productos)
                TempData["ErrorMessage"] = "No se puede eliminar la sucursal porque tiene registros asociados (ventas, productos, etc.). Elimine primero los registros dependientes.";
                // Log the exception
                return RedirectToAction("Delete", new { id = id, saveChangesError = true }); // Redirect back to Delete view with an error
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error inesperado al eliminar la sucursal. Detalles: " + ex.Message;
                // Log the exception
                return RedirectToAction("Delete", new { id = id, saveChangesError = true }); // Redirect back to Delete view with an error
            }
            finally
            {
                // Ensure the context is disposed even if an error occurs
                if (sucursales != null)
                {
                    // This line is often not necessary if the context is disposed globally
                    // but can be useful if you're detaching entities after an error.
                    // db.Entry(sucursales).State = EntityState.Detached;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}